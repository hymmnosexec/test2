// pages/api/activities.js
import db from '../../lib/db';

export default function handler(req, res) {
  // 检查是否为 POST 请求，处理添加活动逻辑
  if (req.method === 'POST') {
    const { title, description, service_hours, creator_username } = req.body;
    if (!title || !description || !service_hours) {
      return res.status(400).json({ message: '所有字段都是必填项。' });
    }
    try {
      const info = db.prepare(
        `INSERT INTO activities (title, description, service_hours, creator_username) VALUES (?, ?, ?, ?)`
      ).run(title, description, service_hours, creator_username);
      return res.status(200).json({ message: '活动创建成功！' });
    } catch (error) {
      console.error('创建活动失败:', error);
      return res.status(500).json({ message: '创建活动时发生错误。' });
    }
  }

  // 检查是否为 DELETE 请求，处理删除活动逻辑
  if (req.method === 'DELETE') {
    const { id } = req.body;
    if (!id) {
      return res.status(400).json({ message: '缺少活动ID。' });
    }
    
    // 使用事务确保数据完整性
    const deleteTransaction = db.transaction(() => {
      // 1. 先删除所有相关的报名记录
      const deleteSignups = db.prepare("DELETE FROM signups WHERE activity_id = ?");
      deleteSignups.run(id);

      // 2. 然后删除活动本身
      const deleteActivity = db.prepare("DELETE FROM activities WHERE id = ?");
      const result = deleteActivity.run(id);
      
      return result;
    });

    try {
      const result = deleteTransaction();
      
      if (result.changes === 0) {
        return res.status(404).json({ message: '未找到要删除的活动。' });
      }

      return res.status(200).json({ message: '活动删除成功！' });
    } catch (error) {
      console.error('删除活动时发生错误:', error);
      return res.status(500).json({ message: '删除活动时发生错误。' });
    }
  }

  // 如果是 GET 请求或任何其他请求，返回活动列表
  if (req.method === 'GET') {
    const activities = db.prepare("SELECT * FROM activities").all();
    return res.status(200).json(activities);
  }

  res.status(405).end();
}


